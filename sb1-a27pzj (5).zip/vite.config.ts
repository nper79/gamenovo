import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import dotenv from 'dotenv'

dotenv.config()

export default defineConfig({
  plugins: [react()],
  define: {
    'process.env': {},
    'import.meta.env.VITE_OPENAI_API_KEY': JSON.stringify(process.env.VITE_OPENAI_API_KEY),
    'import.meta.env.VITE_REPLICATE_API_TOKEN': JSON.stringify(process.env.VITE_REPLICATE_API_TOKEN),
  },
  server: {
    port: 3000,
    strictPort: false,
  },
})