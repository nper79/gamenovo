import OpenAI from 'openai';
import { GameState } from '../types';

const openai = new OpenAI({
  apiKey: import.meta.env.VITE_OPENAI_API_KEY,
  dangerouslyAllowBrowser: true
});

export async function generateStory(context: any): Promise<GameState> {
  try {
    console.log('Generating story with context:', context);
    const completion = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        { role: "system", content: "You are a creative storyteller for an interactive language learning game. Generate engaging story segments with options for the user to choose from." },
        { role: "user", content: `Generate a story segment based on this context: ${JSON.stringify(context)}. Include a short story text, 4 options for the user to choose from, and descriptions for background and character images. Respond with a JSON object containing storyText, options (array), backgroundImagePrompt, and characterImagePrompt.` }
      ],
    });

    const response = completion.choices[0].message.content;
    console.log('AI Response:', response);
    if (!response) throw new Error("No response from OpenAI");

    // Parse the response and create a GameState object
    const parsedResponse = JSON.parse(response);
    console.log('Parsed response:', parsedResponse);
    
    return {
      storyText: parsedResponse.storyText,
      options: parsedResponse.options,
      backgroundImage: '',
      characterImage: '',
      backgroundImagePrompt: parsedResponse.backgroundImagePrompt,
      characterImagePrompt: parsedResponse.characterImagePrompt,
    };
  } catch (error) {
    console.error('Error generating story:', error);
    throw error;
  }
}