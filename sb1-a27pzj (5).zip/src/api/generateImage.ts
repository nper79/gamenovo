import Replicate from "replicate";

const replicate = new Replicate({
  auth: import.meta.env.VITE_REPLICATE_API_TOKEN || '',
});

console.log('Replicate API token:', import.meta.env.VITE_REPLICATE_API_TOKEN ? '[PRESENT]' : '[MISSING]');

export async function generateImage(prompt: string): Promise<string> {
  try {
    console.log('Starting image generation with prompt:', prompt);

    const output = await replicate.run(
      "stability-ai/sdxl:5599ed03def1d160a25a63321b4dec97101d98b4674bcc56e41f62f35637",
      {
        input: {
          prompt: prompt,
          image_dimensions: "768x768",
          num_outputs: 1,
          num_inference_steps: 30, // Reduced from 50 to potentially avoid timeouts
          guidance_scale: 7.5,
          scheduler: "DPMSolverMultistep",
        }
      }
    );

    console.log('Replicate API response:', output);

    if (Array.isArray(output) && output.length > 0) {
      console.log('Image generated successfully:', output[0]);
      return output[0] as string;
    } else {
      throw new Error("No image URL in the output");
    }
  } catch (error) {
    console.error('Error generating image:', error);

    if (error.response) {
      console.error('Error response:', error.response.status, error.response.data);
    } else if (error.request) {
      console.error('No response received:', error.request);
    } else {
      console.error('Error details:', error.message || error);
    }

    // Return fallback image
    return `https://source.unsplash.com/random/768x768/?${encodeURIComponent(prompt)}`;
  }
}