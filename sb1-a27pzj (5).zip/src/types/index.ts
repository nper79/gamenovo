export interface GameState {
  backgroundImage: string;
  characterImage: string;
  storyText: string;
  options: string[];
  backgroundImagePrompt: string;
  characterImagePrompt: string;
}

// ... (keep other interfaces unchanged)