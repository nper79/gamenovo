import express from 'express';
import cors from 'cors';

const app = express();
app.use(cors());
app.use(express.json());

const PORT = 3001;

app.post('/api/generate-story', (req, res) => {
  // Mock story generation
  const mockStory = {
    storyText: "You find yourself in a bustling cyberpunk city. Neon lights flicker overhead as hover cars zoom by. What's your next move?",
    options: [
      "Head to the nearest bar",
      "Investigate a dark alley",
      "Visit the local tech market",
      "Look for a job at the megacorp tower"
    ],
    backgroundImage: "cyberpunk city street",
    characterImage: "cyberpunk protagonist"
  };
  res.json(mockStory);
});

app.post('/api/generate-image', (req, res) => {
  // Mock image generation
  const mockImageUrl = "https://source.unsplash.com/random/800x600/?cyberpunk";
  res.json({ imageUrl: mockImageUrl });
});

app.listen(PORT, () => {
  console.log(`Mock backend running on http://localhost:${PORT}`);
});