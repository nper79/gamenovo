import axios from 'axios';

const API_BASE_URL = 'http://localhost:3000/api'; // Replace with your actual API URL

export const generateStory = async (context: any) => {
  const response = await axios.post(`${API_BASE_URL}/generateStory`, context);
  return response.data;
};

export const generateImage = async (prompt: string) => {
  const response = await axios.post(`${API_BASE_URL}/generateImage`, { prompt });
  return response.data;
};

export const translateWord = async (word: string, targetLanguage: string) => {
  const response = await axios.post(`${API_BASE_URL}/translateWord`, { word, targetLanguage });
  return response.data;
};

export const trackWord = async (userId: string, word: string) => {
  const response = await axios.post(`${API_BASE_URL}/trackWord`, { userId, word });
  return response.data;
};

export const getStorySummary = async (userId: string, storyId: string) => {
  const response = await axios.get(`${API_BASE_URL}/getStorySummary`, { params: { userId, storyId } });
  return response.data;
};

export const updateStoryPrompt = async (storyId: string, prompt: string) => {
  const response = await axios.put(`${API_BASE_URL}/updateStoryPrompt`, { storyId, prompt });
  return response.data;
};