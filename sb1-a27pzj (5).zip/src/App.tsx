import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import HomePage from './components/HomePage';
import StorySelection from './components/StorySelection';
import StoryInterface from './components/StoryInterface';

const App: React.FC = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/story/:storyId" element={<StorySelection />} />
        <Route path="/play/:storyId" element={<StoryInterface />} />
      </Routes>
    </Router>
  );
};

export default App;