import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'default' | 'outline';
  children: React.ReactNode;
  className?: string;
}

export const Button: React.FC<ButtonProps> = ({ variant = 'default', children, className = '', ...props }) => {
  const baseClasses = 'px-4 py-2 rounded-md font-semibold transition-colors duration-200';
  const variantClasses = {
    default: 'bg-fuchsia-600 text-white hover:bg-fuchsia-700',
    outline: 'bg-transparent text-gray-100 border border-gray-700 hover:bg-gray-800',
  };

  return (
    <button
      className={`${baseClasses} ${variantClasses[variant]} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
};