import React, { useState } from 'react';
import TranslationTooltip from './TranslationTooltip';

interface WordHighlighterProps {
  text: string;
}

const WordHighlighter: React.FC<WordHighlighterProps> = ({ text }) => {
  const [selectedWord, setSelectedWord] = useState<string | null>(null);
  const [tooltipPosition, setTooltipPosition] = useState<{ x: number; y: number } | null>(null);

  const handleWordClick = (word: string, event: React.MouseEvent) => {
    setSelectedWord(word);
    setTooltipPosition({ x: event.clientX, y: event.clientY });
    // TODO: Implement word tracking logic
  };

  const words = text.split(' ');

  return (
    <p className="text-white">
      {words.map((word, index) => (
        <React.Fragment key={index}>
          <span
            className="cursor-pointer hover:bg-blue-500 hover:bg-opacity-30"
            onClick={(e) => handleWordClick(word, e)}
          >
            {word}
          </span>
          {index < words.length - 1 && ' '}
        </React.Fragment>
      ))}
      {selectedWord && tooltipPosition && (
        <TranslationTooltip
          word={selectedWord}
          position={tooltipPosition}
          onClose={() => setSelectedWord(null)}
        />
      )}
    </p>
  );
};

export default WordHighlighter;