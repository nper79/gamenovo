import React from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';

const games = [
  {
    id: 1,
    title: "The Debugger",
    description: "Paradise or prison? This fantasy VR game traps your mind in a world you may never want to leave. A rogue AI named Persephon...",
    image: "https://source.unsplash.com/random/600x400/?cyberpunk",
  },
  {
    id: 2,
    title: "Halfway Magical",
    description: "Welcome to Covenant House, where second chances come with a hefty price tag. You're a young kleptomancer (a totally legitimate ...",
    image: "https://source.unsplash.com/random/600x400/?magic",
  },
  {
    id: 3,
    title: "How It Ends",
    description: "When tech fails and society crumbles, your impromptu high school 'reunion' becomes a desperate fight for survival...",
    image: "https://source.unsplash.com/random/600x400/?apocalypse",
  },
  {
    id: 4,
    title: "Penwick",
    description: "Penwick is a coastal town in the north of England, settled by Quaker settlers. Penwick is slowly falling apart, and the citizens are ...",
    image: "https://source.unsplash.com/random/600x400/?coastal,town",
  },
  {
    id: 5,
    title: "Cyber Sleuth",
    description: "In a world where data is currency, you're a digital detective navigating the treacherous waters of corporate espionage and AI conspiracies...",
    image: "https://source.unsplash.com/random/600x400/?detective,cyberpunk",
  },
  {
    id: 6,
    title: "Enchanted Realms",
    description: "Step into a world where magic and technology coexist. As a novice spellcoder, your choices will shape the fate of this delicate balance...",
    image: "https://source.unsplash.com/random/600x400/?magic,technology",
  },
  {
    id: 7,
    title: "Quantum Quandary",
    description: "You're a scientist trapped between parallel universes. Can you solve the quantum puzzles and find your way back to your own reality?",
    image: "https://source.unsplash.com/random/600x400/?quantum,science",
  },
  {
    id: 8,
    title: "Lunar Exodus",
    description: "The Moon is dying, and you're in charge of the last lunar colony. Guide your people to survival as you explore the stars for a new home...",
    image: "https://source.unsplash.com/random/600x400/?moon,space",
  },
];

const HomePage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-900 text-gray-100">
      <header className="absolute top-0 left-0 right-0 z-10">
        <div className="container mx-auto px-4 py-6 flex justify-between items-center">
          <div className="text-2xl font-bold">Gaming Platform</div>
          <nav className="space-x-6">
            <a href="#" className="hover:text-cyan-400">Home</a>
            <a href="#" className="hover:text-cyan-400">Games</a>
            <a href="#" className="hover:text-cyan-400">Community</a>
          </nav>
          <Button variant="secondary" className="bg-cyan-500 text-gray-900 hover:bg-cyan-600">Sign In</Button>
        </div>
      </header>

      <main>
        <section className="relative h-screen">
          <img
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-dUXq4I3rkkoeSMhn2VFjnzR040gBDo.png"
            alt="Cyberpunk character"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-gray-900 via-gray-900/70 to-transparent">
            <div className="container mx-auto px-4 h-full flex items-center">
              <div className="max-w-2xl">
                <h1 className="text-5xl md:text-6xl font-bold mb-4 leading-tight">
                  Learn languages playing a{' '}
                  <span className="text-cyan-400">text</span>{' '}
                  <span className="text-cyan-400">adventure</span>
                </h1>
                <p className="text-xl text-gray-300 mb-8">
                  Immerse yourself in interactive narratives. Master new languages through engaging, personalized text-based adventures.
                </p>
                <Button size="lg" className="bg-cyan-500 text-gray-900 hover:bg-cyan-600">Get Started</Button>
              </div>
            </div>
          </div>
        </section>

        <section className="container mx-auto px-4 py-16">
          <h2 className="text-3xl font-bold mb-8">AI DUNGEON ORIGINALS</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {games.map((game) => (
              <Card key={game.id} className="bg-gray-800 overflow-hidden">
                <div className="relative">
                  <img
                    src={game.image}
                    alt={game.title}
                    className="w-full h-48 object-cover"
                  />
                </div>
                <CardContent className="p-4">
                  <h3 className="text-xl font-bold mb-2">{game.title}</h3>
                  <p className="text-sm text-gray-400 mb-4">{game.description}</p>
                  <div className="flex justify-end">
                    <Link to={`/story/${game.id}`}>
                      <Button variant="secondary" size="sm" className="bg-cyan-500 text-gray-900 hover:bg-cyan-600">
                        PLAY
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      </main>

      <footer className="bg-gray-800 py-8">
        <div className="container mx-auto px-4 text-center text-sm text-gray-500">
          © 2024 Gaming Platform. All rights reserved.
        </div>
      </footer>
    </div>
  );
};

export default HomePage;