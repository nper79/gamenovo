import React, { useState, useEffect } from 'react';
import { useParams, useLocation } from 'react-router-dom';
import { generateStory } from '../api/generateStory';
import { generateImage } from '../api/generateImage';
import { GameState } from '../types';
import WordHighlighter from './WordHighlighter';

const StoryInterface: React.FC = () => {
  const { storyId } = useParams<{ storyId: string }>();
  const location = useLocation();
  const { storyLanguage, translationLanguage } = location.state || {};
  const [gameState, setGameState] = useState<GameState>({
    backgroundImage: '',
    characterImage: '',
    storyText: '',
    options: [],
    backgroundImagePrompt: '',
    characterImagePrompt: '',
  });
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchStorySegment();
  }, [storyId, storyLanguage, translationLanguage]);

  const fetchStorySegment = async (context: any = {}) => {
    setIsLoading(true);
    setError(null);
    try {
      console.log('Fetching story segment with context:', context);
      const storyData = await generateStory({ ...context, storyId, storyLanguage, translationLanguage });
      console.log('Story data received:', storyData);

      let backgroundImage, characterImage;
      try {
        backgroundImage = await generateImage(storyData.backgroundImagePrompt);
      } catch (imgError) {
        console.error('Error generating background image:', imgError);
        backgroundImage = `https://source.unsplash.com/random/768x768/?${encodeURIComponent(storyData.backgroundImagePrompt)}`;
      }

      try {
        characterImage = await generateImage(storyData.characterImagePrompt);
      } catch (imgError) {
        console.error('Error generating character image:', imgError);
        characterImage = `https://source.unsplash.com/random/768x768/?${encodeURIComponent(storyData.characterImagePrompt)}`;
      }

      setGameState({
        ...storyData,
        backgroundImage,
        characterImage,
      });
    } catch (error) {
      console.error('Error fetching story segment:', error);
      setError('Failed to load the story. Please try again later.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleOption = async (option: string) => {
    await fetchStorySegment({ previousChoice: option });
  };

  if (isLoading) {
    return <div className="flex items-center justify-center min-h-screen">Loading...</div>;
  }

  if (error) {
    return <div className="flex items-center justify-center min-h-screen text-red-500">{error}</div>;
  }

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-900">
      <div className="w-full max-w-4xl aspect-[16/9] bg-gray-800 rounded-lg overflow-hidden shadow-lg">
        <div className="relative h-full">
          <img
            src={gameState.backgroundImage}
            alt="Story background"
            className="absolute inset-0 w-full h-full object-cover"
          />
          <div className="absolute top-4 right-4 w-1/3">
            {gameState.options.map((option, index) => (
              <button
                key={index}
                className="w-full p-2 mb-2 bg-gray-900 bg-opacity-75 text-white text-left hover:bg-opacity-90 transition duration-200 rounded"
                onClick={() => handleOption(option)}
              >
                {`> ${option}`}
              </button>
            ))}
          </div>
          <div className="absolute bottom-0 left-0 right-0 h-1/3 flex bg-gray-900 bg-opacity-75">
            <div className="relative w-1/4 h-full">
              <img
                src={gameState.characterImage}
                alt="Character"
                className="absolute bottom-0 left-0 w-full h-auto object-contain object-bottom"
              />
            </div>
            <div className="flex-1 p-4 overflow-y-auto">
              <WordHighlighter text={gameState.storyText} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StoryInterface;