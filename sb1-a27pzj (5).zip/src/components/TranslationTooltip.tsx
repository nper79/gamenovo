import React, { useState, useEffect } from 'react';

interface TranslationTooltipProps {
  word: string;
  position: { x: number; y: number };
  onClose: () => void;
}

const TranslationTooltip: React.FC<TranslationTooltipProps> = ({ word, position, onClose }) => {
  const [translation, setTranslation] = useState('');

  useEffect(() => {
    const fetchTranslation = async () => {
      // TODO: Implement actual translation API call
      // For now, we'll use a mock translation
      setTranslation(`Translated: ${word}`);
    };
    fetchTranslation();
  }, [word]);

  return (
    <div
      className="absolute bg-white text-black p-2 rounded shadow-lg"
      style={{ top: `${position.y + 10}px`, left: `${position.x}px` }}
    >
      <p>{translation}</p>
      <button onClick={onClose} className="text-sm text-blue-500 mt-1">Close</button>
    </div>
  );
};

export default TranslationTooltip;