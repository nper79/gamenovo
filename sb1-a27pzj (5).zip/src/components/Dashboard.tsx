import React from 'react';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import LanguageSelector from './LanguageSelector';

const games = [
  {
    id: 1,
    title: "The Debugger",
    description: "Paradise or prison? This fantasy VR game traps your mind in a world you may never want to leave. A rogue AI named Persephon...",
    image: "https://source.unsplash.com/random/600x400/?cyberpunk",
  },
  {
    id: 2,
    title: "Halfway Magical",
    description: "Welcome to Covenant House, where second chances come with a hefty price tag. You're a young kleptomancer (a totally legitimate ...",
    image: "https://source.unsplash.com/random/600x400/?magic",
  },
  {
    id: 3,
    title: "How It Ends",
    description: "When tech fails and society crumbles, your impromptu high school 'reunion' becomes a desperate fight for survival...",
    image: "https://source.unsplash.com/random/600x400/?apocalypse",
  },
  {
    id: 4,
    title: "Penwick",
    description: "Penwick is a coastal town in the north of England, settled by Quaker settlers. Penwick is slowly falling apart, and the citizens are ...",
    image: "https://source.unsplash.com/random/600x400/?coastal,town",
  },
];

const Dashboard: React.FC = () => {
  const [selectedLanguage, setSelectedLanguage] = React.useState('en');

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100">
      <header className="container mx-auto p-4 flex justify-between items-center">
        <div className="text-2xl font-bold">Language Learning Adventure</div>
        <nav className="space-x-4">
          <a href="#" className="hover:text-gray-300">Home</a>
          <a href="#" className="hover:text-gray-300">Games</a>
          <a href="#" className="hover:text-gray-300">Community</a>
        </nav>
        <div className="flex items-center space-x-4">
          <LanguageSelector selectedLanguage={selectedLanguage} onLanguageChange={setSelectedLanguage} />
          <Button variant="outline">Sign In</Button>
        </div>
      </header>

      <main className="container mx-auto p-4">
        <section className="mb-12">
          <div className="relative overflow-hidden rounded-lg">
            <img
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-dUXq4I3rkkoeSMhn2VFjnzR040gBDo.png"
              alt="Cyberpunk character"
              className="w-full h-auto object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-gray-900 via-gray-900/70 to-transparent">
              <div className="p-8 md:p-12 lg:p-16 max-w-2xl h-full flex flex-col justify-center">
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4 leading-tight">
                  Learn languages playing a{' '}
                  <span className="text-cyan-400">text</span>{' '}
                  <span className="text-cyan-400">adventure</span>
                </h1>
                <p className="text-lg md:text-xl text-gray-300 mb-6">
                  Immerse yourself in interactive narratives. Master new languages through engaging, personalized text-based adventures.
                </p>
                <Button className="w-fit bg-cyan-500 text-gray-900 hover:bg-cyan-600">Get Started</Button>
              </div>
            </div>
          </div>
        </section>

        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-4">AI DUNGEON ORIGINALS</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {games.map((game) => (
              <Card key={game.id} className="bg-gray-800 overflow-hidden">
                <div className="relative">
                  <img
                    src={game.image}
                    alt={game.title}
                    className="w-full h-48 object-cover"
                  />
                </div>
                <CardContent className="p-4">
                  <h3 className="text-xl font-bold mb-2">{game.title}</h3>
                  <p className="text-sm text-gray-400 mb-4">{game.description}</p>
                  <div className="flex justify-end">
                    <Button variant="outline" className="flex items-center bg-cyan-500 text-gray-900 hover:bg-cyan-600">
                      PLAY
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      </main>

      <footer className="mt-12 py-6 bg-gray-800 text-center text-sm text-gray-500">
        © 2024 Language Learning Adventure. All rights reserved.
      </footer>
    </div>
  );
};

export default Dashboard;