import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';

const languages = [
  { code: "en", name: "English" },
  { code: "es", name: "Español" },
  { code: "fr", name: "Français" },
  { code: "de", name: "Deutsch" },
];

const StorySelection: React.FC = () => {
  const { storyId } = useParams<{ storyId: string }>();
  const navigate = useNavigate();
  const [storyLanguage, setStoryLanguage] = useState(languages[0]);
  const [translationLanguage, setTranslationLanguage] = useState(languages[0]);

  const handleStartAdventure = () => {
    navigate(`/play/${storyId}`, { state: { storyLanguage, translationLanguage } });
  };

  return (
    <div className="min-h-screen bg-black text-white flex items-center justify-center p-4">
      <Card className="container max-w-6xl bg-gray-900 p-6 rounded-lg shadow-lg">
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-2 space-y-4">
              <div className="border border-gray-700 rounded-lg overflow-hidden aspect-video">
                <img
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-GzKWFI7YADkOmyYg33sKlYYa7OGJN7.png"
                  alt="Futuristic cityscape at night"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="bg-gray-800 p-4 rounded-lg">
                <h2 className="text-lg font-semibold mb-2 text-white">Story Summary</h2>
                <p className="text-gray-300">
                  Dive into a neon-drenched cyberpunk world where megacorporations rule and technology blurs the line between reality and virtual existence. Navigate the rain-slicked streets of a sprawling metropolis, hack into secure networks, and uncover conspiracies that threaten to reshape society. Your choices will determine the fate of this futuristic realm in this immersive RPG experience.
                </p>
              </div>
            </div>
            <div className="space-y-6">
              <div>
                <label htmlFor="story-language" className="block text-sm font-medium mb-2 text-gray-300">
                  Choose story language
                </label>
                <select
                  id="story-language"
                  value={storyLanguage.code}
                  onChange={(e) => setStoryLanguage(languages.find(lang => lang.code === e.target.value) || languages[0])}
                  className="w-full bg-gray-800 text-white border-gray-700 rounded-md p-2"
                >
                  {languages.map((lang) => (
                    <option key={lang.code} value={lang.code}>
                      {lang.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label htmlFor="translation-language" className="block text-sm font-medium mb-2 text-gray-300">
                  Choose translation language
                </label>
                <select
                  id="translation-language"
                  value={translationLanguage.code}
                  onChange={(e) => setTranslationLanguage(languages.find(lang => lang.code === e.target.value) || languages[0])}
                  className="w-full bg-gray-800 text-white border-gray-700 rounded-md p-2"
                >
                  {languages.map((lang) => (
                    <option key={lang.code} value={lang.code}>
                      {lang.name}
                    </option>
                  ))}
                </select>
              </div>
              <Button className="w-full bg-fuchsia-600 hover:bg-fuchsia-700 text-white" onClick={handleStartAdventure}>
                Start Adventure
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default StorySelection;