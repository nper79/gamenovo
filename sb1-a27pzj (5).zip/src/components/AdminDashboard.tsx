import React from 'react';
import { Link } from 'react-router-dom';

const AdminDashboard: React.FC = () => {
  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl mb-4">Admin Dashboard</h1>
      <ul>
        <li>
          <Link to="/admin/edit/1" className="text-blue-500 hover:underline">
            Edit Cyberpunk Adventure
          </Link>
        </li>
        <li>
          <Link to="/admin/edit/2" className="text-blue-500 hover:underline">
            Edit Medieval Quest
          </Link>
        </li>
      </ul>
    </div>
  );
};

export default AdminDashboard;